package com.example.gestoriaasistente;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;

public class CustomerDbHelper extends SQLiteOpenHelper {
    public CustomerDbHelper(Context context) { super(context, "dentaljg.db", null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pacientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, telefono TEXT NOT NULL, tratamiento TEXT DEFAULT '', total REAL NOT NULL, pagado REAL NOT NULL DEFAULT 0, remote_id TEXT, clinic TEXT DEFAULT 'DENTAL JG', installments INTEGER DEFAULT 0, installment_amount REAL DEFAULT 0, policy_number TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE pagos (id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id INTEGER NOT NULL, monto REAL NOT NULL, fecha INTEGER NOT NULL, nota TEXT DEFAULT '', remote_id TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion<2){
            try{db.execSQL("ALTER TABLE pacientes ADD COLUMN remote_id TEXT");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE pacientes ADD COLUMN clinic TEXT DEFAULT 'DENTAL JG'");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE pacientes ADD COLUMN installments INTEGER DEFAULT 0");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE pacientes ADD COLUMN installment_amount REAL DEFAULT 0");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE pacientes ADD COLUMN policy_number TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE pagos ADD COLUMN remote_id TEXT");}catch(Exception ignored){}
        }
    }
    public long add(String nombre, String telefono, String tratamiento, double total) {
        ContentValues v = new ContentValues(); v.put("nombre", nombre); v.put("telefono", telefono); v.put("tratamiento", tratamiento); v.put("total", total); v.put("pagado", 0); v.put("clinic","DENTAL JG");
        return getWritableDatabase().insert("pacientes", null, v);
    }
    public Cursor all() { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,(total-pagado) saldo FROM pacientes ORDER BY nombre COLLATE NOCASE", null); }
    public Cursor one(long id) { return getReadableDatabase().rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,(total-pagado) saldo FROM pacientes WHERE id=?", new String[]{String.valueOf(id)}); }
    public void delete(long id) { getWritableDatabase().delete("pagos", "paciente_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("pacientes", "id=?", new String[]{String.valueOf(id)}); }
    public boolean payment(long id, double amount, String note) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { ContentValues p=new ContentValues(); p.put("paciente_id",id); p.put("monto",amount); p.put("fecha",System.currentTimeMillis()); p.put("nota",note); db.insertOrThrow("pagos",null,p);
            db.execSQL("UPDATE pacientes SET pagado=pagado+? WHERE id=?",new Object[]{amount,id}); db.setTransactionSuccessful(); return true;
        } catch(Exception e) { return false; } finally { db.endTransaction(); }
    }
    public double sumPaid() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(pagado),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public double sumPending() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(MAX(total-pagado,0)),0) FROM pacientes",null); double n=0; if(c.moveToFirst()) n=c.getDouble(0); c.close(); return n; }
    public int count() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM pacientes",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }
    public Cursor payments() { return getReadableDatabase().rawQuery("SELECT p.nombre,pa.monto,pa.fecha,pa.nota FROM pagos pa JOIN pacientes p ON p.id=pa.paciente_id ORDER BY pa.fecha DESC LIMIT 100",null); }
    public void setRemotePatientId(long localId,String remoteId){ContentValues v=new ContentValues();v.put("remote_id",remoteId);getWritableDatabase().update("pacientes",v,"id=?",new String[]{String.valueOf(localId)});}
    public void setRemotePaymentId(long localId,String remoteId){ContentValues v=new ContentValues();v.put("remote_id",remoteId);getWritableDatabase().update("pagos",v,"id=?",new String[]{String.valueOf(localId)});}
    public void upsertRemotePatient(JSONObject p){
        try{String rid=p.getString("id");ContentValues v=new ContentValues();v.put("remote_id",rid);v.put("nombre",p.optString("name","Paciente"));v.put("telefono",p.optString("phone",""));v.put("tratamiento",p.optString("treatment",""));v.put("total",p.optDouble("total",0));v.put("clinic",p.optString("clinic","DENTAL JG"));v.put("installments",p.optInt("installments",0));v.put("installment_amount",p.optDouble("installment_amount",0));v.put("policy_number",p.optString("policy_number",""));SQLiteDatabase db=getWritableDatabase();Cursor c=db.rawQuery("SELECT id FROM pacientes WHERE remote_id=?",new String[]{rid});boolean exists=c.moveToFirst();long localId=exists?c.getLong(0):-1;c.close();if(exists){Cursor pending=db.rawQuery("SELECT COUNT(*) FROM pagos WHERE paciente_id=? AND (remote_id IS NULL OR remote_id='')",new String[]{String.valueOf(localId)});boolean hasPending=pending.moveToFirst()&&pending.getInt(0)>0;pending.close();if(!hasPending)v.put("pagado",p.optDouble("paid",0));db.update("pacientes",v,"remote_id=?",new String[]{rid});}else{v.put("pagado",p.optDouble("paid",0));db.insert("pacientes",null,v);}}catch(Exception ignored){}
    }
    public void upsertRemotePayment(JSONObject p){
        try{String rid=p.getString("id");Cursor existing=getReadableDatabase().rawQuery("SELECT id FROM pagos WHERE remote_id=?",new String[]{rid});boolean found=existing.moveToFirst();existing.close();if(found)return;String patientRid=p.optString("patient_id","");if(patientRid.isEmpty())return;Cursor pc=getReadableDatabase().rawQuery("SELECT id FROM pacientes WHERE remote_id=?",new String[]{patientRid});if(!pc.moveToFirst()){pc.close();return;}long localPatient=pc.getLong(0);pc.close();ContentValues v=new ContentValues();v.put("remote_id",rid);v.put("paciente_id",localPatient);v.put("monto",p.optDouble("amount",0));v.put("nota",p.optString("reference",p.optString("concept","Abono")));v.put("fecha",System.currentTimeMillis());getWritableDatabase().insert("pagos",null,v);}catch(Exception ignored){}
    }
}
