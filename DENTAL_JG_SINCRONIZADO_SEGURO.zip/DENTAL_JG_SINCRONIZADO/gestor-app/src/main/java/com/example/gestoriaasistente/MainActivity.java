package com.example.gestoriaasistente;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private CustomerDbHelper db;
    private SharedPreferences prefs;
    private SupabaseSync cloud;
    private final ExecutorService cloudExecutor = Executors.newSingleThreadExecutor();
    private boolean cloudDialogShown = false;
    private TextView collectedValue, pendingValue, patientCount;
    private final int navy=Color.rgb(16,37,62), teal=Color.rgb(16,189,183), ink=Color.rgb(27,39,54), muted=Color.rgb(111,129,149);
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        db=new CustomerDbHelper(this); prefs=getSharedPreferences("dentaljg",MODE_PRIVATE); cloud=new SupabaseSync(this);
        collectedValue=findViewById(R.id.collectedValue); pendingValue=findViewById(R.id.pendingValue); patientCount=findViewById(R.id.patientCount);
        findViewById(R.id.btnAddPatient).setOnClickListener(v->addPatient());
        findViewById(R.id.btnPatients).setOnClickListener(v->showPatients());
        findViewById(R.id.btnReports).setOnClickListener(v->showReports());
        findViewById(R.id.btnSettings).setOnClickListener(v->settings());
        findViewById(R.id.btnSyncCloud).setOnClickListener(v->{if(cloud.connected())syncCloud(true);else cloudAccess();});
        refresh();
        findViewById(R.id.btnSettings).setOnLongClickListener(v->{cloudAccess();return true;});
        if(cloud.connected()) syncCloud(false); else new android.os.Handler(getMainLooper()).postDelayed(()->{if(!cloudDialogShown)cloudAccess();},650);
    }
    @Override protected void onResume(){super.onResume();refresh();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
    private String money(double n){return NumberFormat.getCurrencyInstance(new Locale("es","MX")).format(n);}
    private void refresh(){if(collectedValue!=null){collectedValue.setText(money(db.sumPaid()));pendingValue.setText(money(db.sumPending()));patientCount.setText(String.valueOf(db.count()));}}
    private LinearLayout form(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(28,8,28,0);return l;}
    private EditText field(LinearLayout box,String hint,int type){EditText e=new EditText(this);e.setHint(hint);e.setInputType(type);box.addView(e);return e;}
    private void addPatient(){
        LinearLayout f=form(); EditText name=field(f,"Nombre del paciente",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS); EditText phone=field(f,"WhatsApp con lada (10 dígitos)",InputType.TYPE_CLASS_PHONE); EditText treatment=field(f,"Tratamiento o concepto",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); EditText total=field(f,"Costo total del tratamiento ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        new AlertDialog.Builder(this).setTitle("Registrar paciente").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar paciente",(d,w)->{
            String n=name.getText().toString().trim(), p=phone.getText().toString().replaceAll("[^0-9]",""), t=treatment.getText().toString().trim(); double amount=parse(total.getText().toString());
            if(n.isEmpty()||p.length()<10||amount<=0){toast("Revisa nombre, teléfono y costo total.");return;} db.add(n,p,t,amount);refresh();toast("Paciente guardado correctamente.");syncCloud(false);
        }).show();
    }
    private double parse(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}
    private void showPatients(){
        Cursor c=db.all(); LinearLayout list=form(); list.setPadding(24,4,24,4); int count=0;
        while(c.moveToNext()){count++; final long id=c.getLong(0); String name=c.getString(1),phone=c.getString(2),treatment=c.getString(3); double total=c.getDouble(4),paid=c.getDouble(5),balance=c.getDouble(6);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,14,18,14);card.setBackgroundColor(Color.rgb(241,247,250));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=12;list.addView(card,cp);
            TextView n=txt(name,17,ink,true);card.addView(n);card.addView(txt((treatment==null||treatment.isEmpty()?"Tratamiento":treatment)+"  ·  "+phone,12,muted,false));card.addView(txt("Total: "+money(total)+"    Abonado: "+money(paid),13,ink,false));card.addView(txt("Saldo pendiente: "+money(balance),15,balance>0?Color.rgb(174,83,40):Color.rgb(22,132,91),true));
            TextView actions=txt("REGISTRAR ABONO     ·     WHATSAPP     ·     MÁS",11,Color.rgb(0,125,135),true);actions.setPadding(0,12,0,2);card.addView(actions);actions.setOnClickListener(v->patientActions(id,name,phone,total,paid,balance));card.setOnClickListener(v->patientActions(id,name,phone,total,paid,balance));
        }c.close(); if(count==0)list.addView(txt("Aún no hay pacientes. Usa ‘Registrar paciente’ para comenzar.",15,muted,false));
        ScrollView scroll=new ScrollView(this);scroll.addView(list);new AlertDialog.Builder(this).setTitle("Pacientes y saldos").setView(scroll).setPositiveButton("Agregar paciente",(d,w)->addPatient()).setNegativeButton("Cerrar",null).show();
    }
    private void patientActions(long id,String name,String phone,double total,double paid,double balance){
        String[] actions=balance>0?new String[]{"Registrar abono", "Preparar recordatorio por WhatsApp", "Ver pagos y saldo", "Eliminar paciente"}:new String[]{"Ver pagos y saldo","Preparar mensaje por WhatsApp","Eliminar paciente"};
        new AlertDialog.Builder(this).setTitle(name).setItems(actions,(d,which)->{String a=actions[which];if(a.equals("Registrar abono"))addPayment(id,name,balance);else if(a.contains("WhatsApp"))confirmWhatsApp(name,phone,balance);else if(a.equals("Ver pagos y saldo"))showPatientDetails(id,name,total,paid,balance);else if(a.equals("Eliminar paciente"))new AlertDialog.Builder(this).setMessage("¿Eliminar a "+name+" y su historial de pagos?").setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(dd,ww)->{db.delete(id);refresh();showPatients();}).show();}).setNegativeButton("Cerrar",null).show();
    }
    private void addPayment(long id,String name,double balance){LinearLayout f=form();EditText amount=field(f,"Cantidad recibida ($)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);EditText note=field(f,"Nota opcional (efectivo, transferencia…)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(this).setTitle("Registrar abono · "+name).setMessage("Saldo pendiente: "+money(balance)).setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Guardar abono",(d,w)->{double n=parse(amount.getText().toString());if(n<=0){toast("Escribe una cantidad válida.");return;}if(n>balance+0.009){toast("El abono supera el saldo pendiente.");return;}if(db.payment(id,noteAmount(n),note.getText().toString().trim())){refresh();toast("Abono guardado.");syncCloud(false);}else toast("No se pudo guardar el abono.");}).show();}
    private double noteAmount(double n){return n;}
    private void showPatientDetails(long id,String name,double total,double paid,double balance){StringBuilder s=new StringBuilder("Costo total: ").append(money(total)).append("\nAbonado: ").append(money(paid)).append("\nPendiente: ").append(money(balance)).append("\n\nHistorial de pagos:\n");Cursor c=db.payments();int found=0;while(c.moveToNext()){ // payment list is global; filter by patient name to keep helper simple
            if(name.equals(c.getString(0))){found++;s.append(new SimpleDateFormat("d MMM yyyy",new Locale("es","MX")).format(new Date(c.getLong(2)))).append(" — ").append(money(c.getDouble(1)));String note=c.getString(3);if(note!=null&&!note.isEmpty())s.append(" (" ).append(note).append(")");s.append("\n");}}
        c.close();if(found==0)s.append("Sin abonos registrados.");new AlertDialog.Builder(this).setTitle(name).setMessage(s.toString()).setPositiveButton("Aceptar",null).show();}
    private void confirmWhatsApp(String name,String phone,double balance){String template=prefs.getString("message","Hola {nombre}, te recordamos que tienes un saldo pendiente de {saldo} en Dental JG. Si ya realizaste tu pago, por favor ignora este mensaje. ¡Gracias!");String msg=template.replace("{nombre}",name).replace("{saldo}",money(Math.max(0,balance)));
        new AlertDialog.Builder(this).setTitle("Confirmar recordatorio").setMessage("Se abrirá WhatsApp con este mensaje para que tú decidas si enviarlo:\n\n"+msg).setNegativeButton("Cancelar",null).setPositiveButton("Abrir WhatsApp",(d,w)->{try{String digits=phone.replaceAll("[^0-9]","");if(digits.length()==10)digits="52"+digits;Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(msg)));startActivity(i);}catch(Exception e){toast("No se pudo abrir WhatsApp.");}}).show();}
    private void showReports(){Cursor c=db.all();StringBuilder s=new StringBuilder("Resumen de cobranza\n\nTotal cobrado: ").append(money(db.sumPaid())).append("\nSaldo pendiente: ").append(money(db.sumPending())).append("\nPacientes registrados: ").append(db.count()).append("\n\nCuentas pendientes:\n");int n=0;while(c.moveToNext()){double balance=c.getDouble(6);if(balance>0){n++;s.append("• ").append(c.getString(1)).append(" — ").append(money(balance)).append("\n");}}c.close();if(n==0)s.append("No hay saldos pendientes.");new AlertDialog.Builder(this).setTitle("Reporte de cobranza").setMessage(s.toString()).setPositiveButton("Cerrar",null).show();}
    private void settings(){LinearLayout f=form();EditText msg=field(f,"Plantilla de WhatsApp. Usa {nombre} y {saldo}.",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);msg.setMinLines(4);msg.setText(prefs.getString("message","Hola {nombre}, te recordamos que tienes un saldo pendiente de {saldo} en Dental JG. Si ya realizaste tu pago, por favor ignora este mensaje. ¡Gracias!"));TextView cloudState=txt(cloud.connected()?"Nube: conectada como "+cloud.email():"Nube: no conectada",13,muted,false);cloudState.setPadding(0,18,0,4);f.addView(cloudState);Button cloudButton=new Button(this);cloudButton.setText(cloud.connected()?"Sincronizar con panel administrativo":"Conectar con panel administrativo");f.addView(cloudButton);cloudButton.setOnClickListener(v->{cloudAccess();});new AlertDialog.Builder(this).setTitle("Ajustes de DENTAL JG").setMessage("Personaliza WhatsApp o conecta la base de datos compartida.").setView(f).setNegativeButton("Cerrar",null).setPositiveButton("Guardar mensaje",(d,w)->{String m=msg.getText().toString().trim();if(!m.isEmpty())prefs.edit().putString("message",m).apply();toast("Ajustes guardados.");}).show();}
    private void cloudAccess(){cloudDialogShown=true;LinearLayout f=form();EditText email=field(f,"Correo del panel administrativo",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);EditText password=field(f,"Contraseña del panel",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);if(cloud.connected())email.setText(cloud.email());new AlertDialog.Builder(this).setTitle("Conectar DENTAL JG").setMessage("Usa el mismo correo y contraseña que utilizas en el panel web. Los datos se compartirán con Supabase.").setView(f).setNegativeButton("Ahora no",null).setNeutralButton(cloud.connected()?"Desconectar":null,(d,w)->{cloud.logout();toast("Sesión de nube cerrada.");}).setPositiveButton(cloud.connected()?"Volver a sincronizar":"Conectar y sincronizar",(d,w)->{String em=email.getText().toString().trim(),pw=password.getText().toString();if(cloud.connected()&&pw.isEmpty()){syncCloud(true);return;}if(em.isEmpty()||pw.isEmpty()){toast("Escribe correo y contraseña.");return;}toast("Conectando con la base de datos…");cloudExecutor.execute(()->{try{cloud.login(em,pw);cloud.sync(db);runOnUiThread(()->{refresh();toast("Conectado: gestor y panel ya comparten datos.");});}catch(Exception e){runOnUiThread(()->toast("No se pudo sincronizar: "+e.getMessage()));}});}).show();}
    private void syncCloud(boolean showMessage){if(!cloud.connected()){if(showMessage)cloudAccess();return;}cloudExecutor.execute(()->{try{cloud.sync(db);runOnUiThread(()->{refresh();if(showMessage)toast("Sincronización con el panel completada.");});}catch(Exception e){runOnUiThread(()->{if(showMessage)toast("Error al sincronizar: "+e.getMessage());});}});}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
