BEGIN;

-- DENTAL JG - Fase 10: acceso por roles y sincronización Gestor por RPC.
-- Elimina políticas permisivas conocidas en pacientes/pagos/clínicas/gestores.
-- Gestor solo puede consultar y registrar movimientos del gestor validado por clave.

CREATE OR REPLACE FUNCTION public.dental_jg_manager_by_key(p_manager_key text)
RETURNS TABLE(id uuid, full_name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para validar al gestor.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  IF length(trim(coalesce(p_manager_key,''))) < 4 THEN RAISE EXCEPTION 'Clave de gestor no válida.'; END IF;
  RETURN QUERY SELECT m.id,m.full_name FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(p_manager_key) LIMIT 1;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_patients(p_manager_key text)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para sincronizar pacientes.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  RETURN QUERY SELECT to_jsonb(p) FROM public.patients p
  WHERE p.assigned_manager_id=v_manager ORDER BY p.created_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_payments(p_manager_key text)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para sincronizar pagos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  RETURN QUERY SELECT to_jsonb(py) FROM public.payments py
  JOIN public.patients pt ON pt.id=py.patient_id
  WHERE pt.assigned_manager_id=v_manager ORDER BY py.paid_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_insert_payment(p_manager_key text,p_payment jsonb)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid; v_patient public.patients; v_payment public.payments; v_operation_id text; v_amount numeric;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para registrar pagos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  v_operation_id:=trim(coalesce(p_payment->>'client_operation_id',''));
  IF v_operation_id='' THEN RAISE EXCEPTION 'El pago no incluye identificador único. Actualiza la aplicación Gestor.'; END IF;
  v_amount:=(p_payment->>'amount')::numeric;
  IF v_amount IS NULL OR v_amount<=0 OR v_amount>9999999999.99 THEN RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.'; END IF;
  -- Autoriza al gestor sobre el paciente antes de consultar identificadores existentes.
  SELECT p.* INTO v_patient FROM public.patients p
  WHERE p.id=(p_payment->>'patient_id')::uuid AND p.assigned_manager_id=v_manager
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no pertenece a este gestor.'; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('dentaljg-payment-operation:'||v_operation_id));
  SELECT * INTO v_payment FROM public.payments WHERE client_operation_id=v_operation_id LIMIT 1;
  IF FOUND THEN
    IF v_payment.patient_id IS DISTINCT FROM v_patient.id OR round(v_payment.amount,2)<>round(v_amount,2) THEN
      RAISE EXCEPTION 'El identificador de operación ya existe con datos diferentes. No se registró otro pago.';
    END IF;
    RETURN NEXT to_jsonb(v_payment); RETURN;
  END IF;
  IF v_amount > GREATEST(COALESCE(v_patient.total,0)-COALESCE(v_patient.paid,0),0) + 0.009 THEN
    RAISE EXCEPTION 'El pago supera el saldo pendiente actual. Sincroniza el paciente y revisa el historial antes de reintentar.';
  END IF;
  INSERT INTO public.payments(patient_id,patient_name,amount,concept,reference,paid_at,source_device,client_operation_id)
  VALUES(v_patient.id,
    coalesce(nullif(trim(concat_ws(' ',nullif(v_patient.first_names,''),nullif(v_patient.surnames,''))),''),v_patient.name),
    v_amount,coalesce(nullif(trim(p_payment->>'concept'),''),'Abono'),coalesce(p_payment->>'reference',''),
    coalesce(nullif(p_payment->>'paid_at','')::timestamptz,now()),
    coalesce(nullif(p_payment->>'source_device',''),'DENTAL JG APK'),v_operation_id)
  RETURNING * INTO v_payment;
  RETURN NEXT to_jsonb(v_payment);
END; $$;

REVOKE ALL ON FUNCTION public.dental_jg_manager_by_key(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_patients(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_payments(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_insert_payment(text,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_by_key(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_patients(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_payments(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_insert_payment(text,jsonb) TO authenticated;

DO $$ DECLARE pol record; BEGIN
  FOR pol IN SELECT tablename,policyname FROM pg_policies WHERE schemaname='public'
    AND tablename IN ('patients','payments','clinics','collection_managers') LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',pol.policyname,pol.tablename);
  END LOOP;
END; $$;

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clinics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collection_managers ENABLE ROW LEVEL SECURITY;

CREATE POLICY dental_jg_staff_read_patients ON public.patients FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
CREATE POLICY dental_jg_staff_update_patients ON public.patients FOR UPDATE TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza'))) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
CREATE POLICY dental_jg_staff_delete_patients ON public.patients FOR DELETE TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
REVOKE ALL ON public.patients FROM PUBLIC,anon,authenticated;
GRANT SELECT,UPDATE,DELETE ON public.patients TO authenticated;

CREATE POLICY dental_jg_staff_read_payments ON public.payments FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
REVOKE ALL ON public.payments FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.payments TO authenticated;

CREATE POLICY dental_jg_authenticated_read_clinics ON public.clinics FOR SELECT TO authenticated USING (true);
CREATE POLICY dental_jg_staff_manage_clinics ON public.clinics FOR ALL TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza'))) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
REVOKE ALL ON public.clinics FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.clinics TO authenticated;

REVOKE ALL ON public.collection_managers FROM PUBLIC,anon,authenticated;
REVOKE SELECT(manager_key) ON public.collection_managers FROM PUBLIC,anon,authenticated;
GRANT SELECT(id,created_by,full_name,phone,active,created_at,updated_at) ON public.collection_managers TO authenticated;
GRANT INSERT(created_by,full_name,phone,manager_key) ON public.collection_managers TO authenticated;
GRANT UPDATE(full_name,phone,manager_key,active,updated_at) ON public.collection_managers TO authenticated;
GRANT DELETE ON public.collection_managers TO authenticated;
CREATE POLICY dental_jg_staff_read_managers ON public.collection_managers FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
CREATE POLICY dental_jg_admin_manage_managers ON public.collection_managers FOR ALL TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin')) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));

COMMIT;
