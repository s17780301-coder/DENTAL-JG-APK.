-- DENTAL JG 10.8 — SQL mínimo para habilitar Registro de clientes.
-- Este archivo NO crea ni elimina tablas de Cobranza y NO cambia políticas de patients.
-- Ejecutar una sola vez desde Supabase SQL Editor si aún no se ha aplicado.

BEGIN;

CREATE TABLE IF NOT EXISTS public.app_user_roles (
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role text NOT NULL CHECK (role IN ('registro', 'cobranza', 'gestor', 'admin')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, role)
);

ALTER TABLE public.app_user_roles ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.app_user_roles FROM anon, authenticated;
GRANT SELECT ON TABLE public.app_user_roles TO authenticated;
DROP POLICY IF EXISTS "users view own app roles" ON public.app_user_roles;
CREATE POLICY "users view own app roles"
ON public.app_user_roles FOR SELECT TO authenticated
USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.register_dental_jg_patient(
    p_name text,
    p_phone text,
    p_treatment text,
    p_total numeric,
    p_installments integer,
    p_installment_amount numeric,
    p_policy_number text,
    p_clinic text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id uuid;
    v_patient_id uuid;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Debes iniciar sesión';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM public.app_user_roles
        WHERE user_id = v_user_id AND role IN ('registro', 'admin')
    ) THEN
        RAISE EXCEPTION 'No tienes permiso para registrar pacientes';
    END IF;
    IF NULLIF(TRIM(COALESCE(p_name, '')), '') IS NULL
       OR NULLIF(TRIM(COALESCE(p_clinic, '')), '') IS NULL THEN
        RAISE EXCEPTION 'El nombre y la clínica son obligatorios';
    END IF;
    IF COALESCE(p_total, 0) < 0
       OR COALESCE(p_installments, 0) < 0
       OR COALESCE(p_installment_amount, 0) < 0 THEN
        RAISE EXCEPTION 'Los importes y pagos no pueden ser negativos';
    END IF;

    INSERT INTO public.patients (
        name, phone, treatment, total, paid, installments,
        installment_amount, policy_number, clinic, source_device,
        created_at, updated_at
    ) VALUES (
        TRIM(p_name), COALESCE(TRIM(p_phone), ''), COALESCE(TRIM(p_treatment), ''),
        COALESCE(p_total, 0), 0, COALESCE(p_installments, 0),
        COALESCE(p_installment_amount, 0), COALESCE(TRIM(p_policy_number), ''),
        TRIM(p_clinic), 'DENTAL JG Registro', now(), now()
    ) RETURNING id INTO v_patient_id;

    RETURN v_patient_id;
END;
$$;

REVOKE ALL ON FUNCTION public.register_dental_jg_patient(
    text, text, text, numeric, integer, numeric, text, text
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.register_dental_jg_patient(
    text, text, text, numeric, integer, numeric, text, text
) TO authenticated;

DO $$
DECLARE
    v_user_id uuid;
BEGIN
    SELECT id INTO v_user_id
    FROM auth.users
    WHERE lower(email) = lower('clinicadentaljgadmon@outlook.com')
    LIMIT 1;
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'No se encontró clinicadentaljgadmon@outlook.com en Supabase Auth';
    END IF;
    INSERT INTO public.app_user_roles (user_id, role)
    VALUES (v_user_id, 'registro')
    ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

COMMIT;
