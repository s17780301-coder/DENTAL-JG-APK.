# DENTAL JG · integración de las tres apps

## App de cobranza v1.0
La tercera app está en `cobranza-app` (APK Android) y `cobranza-web` (PWA instalable en Windows/Android). Lee pacientes y pagos desde la misma instancia de Supabase, escucha eventos Realtime de `patients`, `payments` y `collection_receipts`, y crea recibos de cobranza vinculados a un pago o manuales.

Antes del primer uso, ejecutar `cobranza-web/supabase_cobranza_v1.sql` en SQL Editor de Supabase. El SQL es aditivo: crea tablas de configuración y recibos, políticas RLS y una función transaccional que reserva folios únicos por usuario. Copia del mismo SQL incluida en `cobranza-app/src/main/assets/supabase_cobranza_v1.sql`.

La plantilla permite cambiar encabezado, pie, prefijo y numeración del folio, dígitos y tabulador predeterminado. En cada recibo se puede corregir paciente, clínica, fecha, importe, saldo anterior, tabulador, concepto y notas; tiene vista previa e impresión/guardar como PDF; los recibos guardados se pueden editar conservando el folio.

Fórmula actual visible en pantalla: neto = importe cobrado − saldo anterior − tabulador. Nuevo saldo estimado = max(0, saldo anterior − importe cobrado). El saldo anterior sugerido se obtiene de total menos pagado del paciente, pero se puede editar. Confirmar con el usuario la interpretación contable antes de operar en producción si el tabulador representa otra cosa.

## Contrato de datos
La app de gestoría sincroniza pagos en `public.payments` ligados a `public.patients` mediante `patient_id`. Campos base: `payment_id`, `patient_id`, `patient_name`, `amount`, `concept`, `reference`, `paid_at`, `source_device` y clínica del paciente. La app de cobranza no duplica ni modifica los pagos recibidos; genera recibos en `public.collection_receipts`.

## Validaciones pendientes
- Ejecutar el SQL en el proyecto Supabase real y confirmar RLS / publicación Realtime.
- Compilar la APK `:cobranza-app:assembleDebug` con GitHub Actions.
- Probar en Android la sesión, llegada de pagos nuevos, folio concurrente e impresión.
- Publicar `cobranza-web` por HTTPS para instalarla en Windows como PWA.
