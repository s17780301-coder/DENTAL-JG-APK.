package com.example.gestoriaasistente;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Sincroniza la caché local de DENTAL JG con las mismas tablas usadas por el panel web. */
public final class SupabaseSync {
    public static final String BASE = "https://nfwhymppyzoriihdwlyc.supabase.co";
    public static final String ANON = "sb_publishable_4n5cK2gQeEbTtdYKHAWVVQ_C1Gzl88O";
    private static final String PREF = "dentaljg_cloud";
    private static final String KEY_ALIAS = "dentaljg_manager_key_v1";
    private final Context context;
    public SupabaseSync(Context c) { context = c.getApplicationContext(); }
    public String token() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("access_token", ""); }
    public String email() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("email", ""); }
    public boolean connected() { return !token().isEmpty(); }
    public String managerId() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("manager_id", ""); }
    public String managerName() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("manager_name", ""); }
    private String managerKey() throws Exception {
        SharedPreferences prefs=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String ivText=prefs.getString("manager_key_iv", ""), encrypted=prefs.getString("manager_key_enc", "");
        if(ivText.isEmpty()||encrypted.isEmpty()) return "";
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        SecretKey secret=(SecretKey)ks.getKey(KEY_ALIAS,null);
        if(secret==null) return "";
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,secret,new GCMParameterSpec(128,Base64.decode(ivText,Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(encrypted,Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }
    private void storeManagerKey(String key) throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        SecretKey secret;
        if(ks.containsAlias(KEY_ALIAS)) secret=(SecretKey)ks.getKey(KEY_ALIAS,null);
        else {
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
            secret=generator.generateKey();
        }
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,secret);
        byte[] encrypted=cipher.doFinal(key.getBytes(StandardCharsets.UTF_8));
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putString("manager_key_iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP))
            .putString("manager_key_enc",Base64.encodeToString(encrypted,Base64.NO_WRAP)).apply();
    }
    private JSONObject managerKeyPayload(String key) throws Exception { JSONObject body=new JSONObject(); body.put("p_manager_key",key); return body; }
    public void verifyManagerKey(String key) throws Exception {
        if (key == null || key.trim().length() < 4) throw new Exception("Escribe la clave de gestor asignada por Administración.");
        JSONObject body = new JSONObject(); body.put("p_manager_key", key.trim());
        JSONArray result = requestArray("POST", "/rest/v1/rpc/dental_jg_manager_by_key", body, token(), null);
        if (result.length() == 0) throw new Exception("Clave de gestor incorrecta o gestor inactivo. Pide a Administración que la revise.");
        JSONObject manager = result.getJSONObject(0);
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("manager_id", manager.optString("id", "")).putString("manager_name", manager.optString("full_name", "")).apply();
        storeManagerKey(key.trim());
    }

    public String login(String email, String password) throws Exception {
        JSONObject body = new JSONObject(); body.put("email", email); body.put("password", password);
        JSONObject result = request("POST", "/auth/v1/token?grant_type=password", body, null, null);
        String access = result.optString("access_token", "");
        if (access.isEmpty()) throw new Exception("Supabase no devolvió una sesión válida.");
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("access_token", access).putString("refresh_token", result.optString("refresh_token", "")).putString("email", email).apply();
        return access;
    }
    public void logout() { context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply(); }

    public void sync(CustomerDbHelper db) throws Exception {
        String jwt = token(); if (jwt.isEmpty()) throw new Exception("Primero inicia sesión con el mismo correo y contraseña del panel administrativo.");
        String assignedManager = managerId(); if (assignedManager.isEmpty()) throw new Exception("Primero valida la clave del gestor asignada por Administración.");
        String key=managerKey(); if(key.isEmpty()) throw new Exception("Vuelve a validar la clave del gestor para sincronizar de forma segura.");
        SQLiteDatabase local = db.getWritableDatabase();
        // Leer primero la nube. Si un paciente ya existe en ambos lados, enlazarlo por teléfono + nombre
        // antes de subirlo para evitar crear un duplicado.
        JSONArray remotePatients = requestArray("POST", "/rest/v1/rpc/dental_jg_manager_patients", managerKeyPayload(key), jwt, null);
        Cursor unsynced = local.rawQuery("SELECT id,nombre,telefono,tratamiento,total,pagado,remote_id,clinica,quincenas,pago_quincenal,numero_poliza FROM pacientes WHERE remote_id IS NULL OR remote_id=''", null);
        try { while (unsynced.moveToNext()) {
            String localName = blank(unsynced.getString(1), "");
            String localPhone = digits(unsynced.getString(2));
            String matchedRemoteId = "";
            if (!localPhone.isEmpty()) {
                for (int i = 0; i < remotePatients.length(); i++) {
                    JSONObject candidate = remotePatients.getJSONObject(i);
                    if (localPhone.equals(digits(candidate.optString("phone", "")))
                            && localName.equalsIgnoreCase(blank(candidate.optString("name", ""), ""))) {
                        matchedRemoteId = candidate.optString("id", "");
                        if (!matchedRemoteId.isEmpty()) break;
                    }
                }
            }
            if (!matchedRemoteId.isEmpty()) {
                db.setRemotePatientId(unsynced.getLong(0), matchedRemoteId);
                continue;
            }
            throw new Exception("El paciente local «" + localName + "» no existe en Registro de clientes. Por seguridad, Gestor ya no da de alta pacientes directamente. Regístralo primero en la app Registro de clientes y vuelve a sincronizar para enlazarlo por nombre y teléfono.");
        }} finally { unsynced.close(); }

        // 2) Descargar pacientes del panel y actualizar la copia local sin duplicarlos.
        remotePatients = requestArray("POST", "/rest/v1/rpc/dental_jg_manager_patients", managerKeyPayload(key), jwt, null);
        for (int i=0;i<remotePatients.length();i++) { JSONObject p=remotePatients.getJSONObject(i); db.upsertRemotePatient(p); }

        // 3) Subir abonos locales aún no sincronizados, con el UUID real del paciente.
        Cursor localPayments = local.rawQuery("SELECT pa.id,pa.paciente_id,pa.monto,pa.fecha,pa.nota,p.nombre,p.remote_id,pa.remote_id,pa.client_operation_id FROM pagos pa JOIN pacientes p ON p.id=pa.paciente_id WHERE pa.remote_id IS NULL OR pa.remote_id=''", null);
        try { while(localPayments.moveToNext()) {
            String patientRemote=localPayments.getString(6); if(patientRemote==null || patientRemote.isEmpty()) continue;
            JSONObject pay=new JSONObject(); pay.put("patient_id",patientRemote); pay.put("patient_name",localPayments.getString(5)); pay.put("amount",localPayments.getDouble(2));
            pay.put("concept",blank(localPayments.getString(4),"Abono")); pay.put("reference",blank(localPayments.getString(4),"")); pay.put("paid_at",isoTimestamp(localPayments.getLong(3))); pay.put("source_device","DENTAL JG APK"); pay.put("client_operation_id",localPayments.getString(8));
            JSONObject paymentRpc=new JSONObject(); paymentRpc.put("p_manager_key",key); paymentRpc.put("p_payment",pay);
            JSONArray saved=requestArray("POST","/rest/v1/rpc/dental_jg_manager_insert_payment",paymentRpc,jwt,null);
            String remotePaymentId = saved.length()>0 ? saved.getJSONObject(0).optString("id","") : "";
            if(!remotePaymentId.isEmpty()) db.setRemotePaymentId(localPayments.getLong(0),remotePaymentId);
        }} finally { localPayments.close(); }

        // 4) Descargar pagos por la RPC autorizada para el gestor.
        // No consultar /rest/v1/patients directamente: la política RLS de producción
        // reserva esa tabla a los módulos administrativos y el gestor usa RPC validada.
        JSONArray remotePayments=requestArray("POST","/rest/v1/rpc/dental_jg_manager_payments",managerKeyPayload(key),jwt,null);
        for(int i=0;i<remotePayments.length();i++) db.upsertRemotePayment(remotePayments.getJSONObject(i));
        // 5) Volver a leer pacientes mediante la RPC para refrescar saldos sin abrir
        // acceso directo a la tabla patients al rol Gestor.
        remotePatients=requestArray("POST", "/rest/v1/rpc/dental_jg_manager_patients", managerKeyPayload(key), jwt, null);
        for(int i=0;i<remotePatients.length();i++) db.upsertRemotePatient(remotePatients.getJSONObject(i));
    }
    private static String isoTimestamp(long millis) { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US); f.setTimeZone(TimeZone.getTimeZone("UTC")); return f.format(new Date(millis)); }
    private static String blank(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
    private static String digits(String s){return s==null?"":s.replaceAll("[^0-9]", "");}
    private JSONObject request(String method,String path,JSONObject body,String jwt,String prefer) throws Exception {
        HttpURLConnection c=open(method,path,jwt,prefer); if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300) throw new Exception(explain(response,code)); return new JSONObject(response.isEmpty()?"{}":response);
    }
    private JSONArray requestArray(String method,String path,JSONObject body,String jwt,String prefer) throws Exception {
        HttpURLConnection c=open(method,path,jwt,prefer); if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300) throw new Exception(explain(response,code)); return new JSONArray(response.isEmpty()?"[]":response);
    }
    private HttpURLConnection open(String method,String path,String jwt,String prefer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("apikey",ANON); c.setRequestProperty("Authorization","Bearer "+(jwt==null?ANON:jwt)); c.setRequestProperty("Accept","application/json"); if(prefer!=null)c.setRequestProperty("Prefer",prefer); return c;
    }
    private String read(InputStream in) throws Exception { if(in==null)return ""; try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);return s.toString();} }
    private String explain(String response,int code){try{JSONObject j=new JSONObject(response);String m=j.optString("message",j.optString("msg",j.optString("error_description",response)));if(code==401)return "La sesión venció. Vuelve a iniciar sesión. "+m;if(code==403)return "Supabase bloqueó el acceso. Revisa las políticas RLS. "+m;return m;}catch(Exception e){return "Error de Supabase ("+code+"): "+response;}}
}
