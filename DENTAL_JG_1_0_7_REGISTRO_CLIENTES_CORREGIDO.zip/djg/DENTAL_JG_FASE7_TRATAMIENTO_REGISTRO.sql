-- DENTAL JG - Fase 7: guardar Tratamiento y Observaciones en sus campos correctos.
-- Migración aditiva: no modifica pacientes existentes, pagos ni saldos.
-- Ejecutar en Supabase después de respaldar y antes de usar la APK/web de Registro corregida.

BEGIN;

CREATE OR REPLACE FUNCTION public.register_dental_jg_patient(
 p_name text, p_phone text, p_treatment text, p_total numeric,
 p_installments integer, p_installment_amount numeric, p_policy_number text, p_clinic text,
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text,
 p_holder_name text, p_payment_mode text, p_tabulator numeric, p_first_payment_date date,
 p_payment_method text DEFAULT 'efectivo', p_policy_type text DEFAULT NULL,
 p_assigned_manager_id uuid DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
  new_folio text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Inicia sesión para registrar clientes.';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.app_user_roles
    WHERE user_id = auth.uid() AND role IN ('registro', 'admin')
  ) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para registrar clientes.';
  END IF;

  IF length(trim(coalesce(p_holder_name, ''))) = 0
     OR length(trim(coalesce(p_first_names, p_name, ''))) = 0
     OR length(trim(coalesce(p_surnames, ''))) = 0
     OR length(trim(coalesce(p_clinic, ''))) = 0
     OR length(trim(coalesce(p_policy_number, ''))) = 0
     OR length(trim(coalesce(p_address, ''))) = 0
     OR length(trim(coalesce(p_phone, ''))) = 0 THEN
    RAISE EXCEPTION 'Completa todos los campos obligatorios.';
  END IF;

  IF coalesce(p_treatment, '') NOT IN ('Básico', 'Orto', 'VIP', 'Damon') THEN
    RAISE EXCEPTION 'Selecciona un tratamiento válido.';
  END IF;

  IF p_assigned_manager_id IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.collection_managers
    WHERE id = p_assigned_manager_id AND coalesce(active, true)
  ) THEN
    RAISE EXCEPTION 'Selecciona un gestor activo.';
  END IF;

  IF coalesce(p_payment_mode, '') NOT IN ('quincenal', 'mensual') THEN
    RAISE EXCEPTION 'Selecciona periodicidad quincenal o mensual.';
  END IF;
  IF coalesce(p_payment_method, '') NOT IN ('efectivo', 'transferencia') THEN
    RAISE EXCEPTION 'Selecciona forma de pago efectivo o transferencia.';
  END IF;
  IF coalesce(p_total, 0) <= 0 OR coalesce(p_installments, 0) < 1
     OR coalesce(p_installment_amount, 0) <= 0 OR coalesce(p_tabulator, 0) < 0
     OR p_first_payment_date IS NULL THEN
    RAISE EXCEPTION 'Verifica monto total, cantidad por pago, número de pagos, tabulador y fecha del primer pago.';
  END IF;

  new_folio := 'JG-' || lpad(nextval('public.dental_jg_patient_folio_seq')::text, 6, '0');

  INSERT INTO public.patients(
    folio, holder_name, first_names, surnames, address, phone2, observations,
    name, phone, treatment, total, paid, installments, installment_amount,
    policy_number, policy_type, assigned_manager_id, clinic, source_device,
    created_at, updated_at, payment_mode, tabulator, first_payment_date, payment_method
  ) VALUES (
    new_folio, trim(p_holder_name), trim(coalesce(p_first_names, p_name)),
    trim(coalesce(p_surnames, '')), trim(coalesce(p_address, '')),
    trim(coalesce(p_phone2, '')), trim(coalesce(p_observations, '')),
    trim(p_name), trim(p_phone), trim(p_treatment), p_total, 0,
    p_installments, p_installment_amount, trim(p_policy_number),
    nullif(trim(coalesce(p_policy_type, '')), ''), p_assigned_manager_id,
    trim(p_clinic), 'DENTAL JG Registro', now(), now(), p_payment_mode,
    p_tabulator, p_first_payment_date, p_payment_method
  ) RETURNING id INTO new_id;

  RETURN new_id;
END;
$$;

REVOKE ALL ON FUNCTION public.register_dental_jg_patient(
 text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,
 text,text,numeric,date,text,text,uuid
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.register_dental_jg_patient(
 text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,
 text,text,numeric,date,text,text,uuid
) TO authenticated;

COMMIT;
