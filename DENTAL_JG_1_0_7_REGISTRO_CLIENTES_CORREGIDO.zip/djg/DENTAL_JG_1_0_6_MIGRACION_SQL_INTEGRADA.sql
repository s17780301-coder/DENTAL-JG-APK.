-- DENTAL JG 1.0.6 — MIGRACIÓN SQL INTEGRADA CORREGIDA
-- ATÓMICA: si falla cualquier comprobación o cambio SQL, PostgreSQL revierte los cambios transaccionales de la migración completa.
-- Respaldar Supabase antes de ejecutar. Ejecutar TODO el archivo una sola vez en el proyecto correcto.
-- No ejecutar por fragmentos. No modifica pagos históricos ni recalcula automáticamente los saldos existentes.
-- Nota: la secuencia de folios puede avanzar aunque la transacción se revierta; esto solo puede dejar saltos de folio, nunca duplicarlos.

BEGIN;

-- DENTAL JG 1.0.6 — MIGRACIÓN SQL INTEGRADA
-- Respaldar Supabase. Ejecutar el archivo completo una sola vez en el proyecto correcto.
-- Endurece RLS y fuerza el alta de pacientes por la RPC protegida, únicamente para el rol registro. El panel Admon no debe insertar pacientes directamente.

-- Preflight: si el esquema no corresponde a DENTAL JG, detenerse antes de modificar datos.
DO $$
DECLARE v_missing text;
BEGIN
  WITH required(table_name,column_name) AS (VALUES
    ('payments','id'),('payments','patient_id'),('payments','amount'),('payments','patient_name'),('payments','concept'),('payments','reference'),('payments','paid_at'),('payments','source_device'),
    ('patients','id'),('patients','name'),('patients','first_names'),('patients','surnames'),('patients','holder_name'),('patients','address'),('patients','phone'),('patients','phone2'),('patients','observations'),('patients','treatment'),('patients','total'),('patients','paid'),('patients','installments'),('patients','installment_amount'),('patients','assigned_manager_id'),('patients','policy_number'),('patients','policy_type'),('patients','clinic'),('patients','source_device'),('patients','created_at'),('patients','updated_at'),('patients','payment_mode'),('patients','tabulator'),('patients','first_payment_date'),('patients','payment_method'),('patients','folio'),
    ('collection_managers','id'),('collection_managers','created_by'),('collection_managers','full_name'),('collection_managers','phone'),('collection_managers','active'),('collection_managers','manager_key'),('collection_managers','created_at'),('collection_managers','updated_at'),
    ('collection_portfolios','id'),('collection_portfolios','created_by'),('collection_portfolios','clinic_name'),('collection_portfolios','name'),('collection_portfolios','manager_id'),('collection_portfolios','updated_at'),
    ('collection_portfolio_patients','id'),('collection_portfolio_patients','created_by'),('collection_portfolio_patients','portfolio_id'),('collection_portfolio_patients','patient_id'),
    ('collection_receipts','id'),('collection_receipts','created_by'),('collection_receipts','folio'),('collection_receipts','payment_id'),('collection_receipts','patient_id'),('collection_receipts','manager_id'),('collection_receipts','scheduled_for'),('collection_receipts','patient_name'),('collection_receipts','clinic'),('collection_receipts','payment_amount'),('collection_receipts','previous_balance'),('collection_receipts','tabulator'),('collection_receipts','net_amount'),('collection_receipts','new_balance'),('collection_receipts','concept'),('collection_receipts','notes'),('collection_receipts','receipt_snapshot'),
    ('collection_receipt_settings','user_id'),('collection_receipt_settings','folio_prefix'),('collection_receipt_settings','next_folio'),('collection_receipt_settings','folio_digits'),('collection_receipt_settings','updated_at'),
    ('app_user_roles','user_id'),('app_user_roles','role'),('clinics','id'),('clinics','name')
  )
  SELECT string_agg(r.table_name||'.'||r.column_name, ', ' ORDER BY r.table_name,r.column_name)
    INTO v_missing
  FROM required r
  WHERE NOT EXISTS (
    SELECT 1 FROM information_schema.columns c
    WHERE c.table_schema='public' AND c.table_name=r.table_name AND c.column_name=r.column_name
  );
  IF v_missing IS NOT NULL THEN
    RAISE EXCEPTION 'DENTAL JG 1.0.6: esquema incompatible; faltan columnas: %. No se aplicó ninguna modificación de este preflight.', v_missing;
  END IF;
END;
$$;

-- DENTAL JG - Fase 6: idempotencia de pagos y saldo consistente.
-- Requiere desplegar las APK revisadas para que Gestor envíe client_operation_id.
-- No borra pagos ni recalcula saldos históricos al instalarse.
-- Respaldar Supabase antes de ejecutar.


ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS client_operation_id text;

-- Normaliza identificadores vacíos antiguos a NULL; no elimina pagos.
UPDATE public.payments SET client_operation_id = NULL
WHERE client_operation_id IS NOT NULL AND btrim(client_operation_id) = '';

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM public.payments WHERE client_operation_id IS NOT NULL
             GROUP BY client_operation_id HAVING count(*) > 1) THEN
    RAISE EXCEPTION 'Hay client_operation_id duplicados existentes en payments. No se creó el índice; concilia esos identificadores antes de continuar.';
  END IF;
END; $$;

-- UUID persistente generado una sola vez por cada pago local.
-- Varios NULL siguen permitidos para conservar compatibilidad con registros/APK antiguos.
CREATE UNIQUE INDEX IF NOT EXISTS payments_client_operation_id_uq
  ON public.payments (client_operation_id);

-- Actualiza el saldo solo por la diferencia real de la fila insertada/modificada/eliminada.
-- No recalcula ni sobrescribe el saldo histórico completo.
CREATE OR REPLACE FUNCTION public.dental_jg_apply_payment_balance_delta()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) + COALESCE(NEW.amount, 0)),
             updated_at = now()
       WHERE id = NEW.patient_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0)),
             updated_at = now()
       WHERE id = OLD.patient_id;
    END IF;
    RETURN OLD;
  ELSE
    IF OLD.patient_id IS DISTINCT FROM NEW.patient_id THEN
      IF OLD.patient_id IS NOT NULL THEN
        UPDATE public.patients
           SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0)),
               updated_at = now()
         WHERE id = OLD.patient_id;
      END IF;
      IF NEW.patient_id IS NOT NULL THEN
        UPDATE public.patients
           SET paid = GREATEST(0, COALESCE(paid, 0) + COALESCE(NEW.amount, 0)),
               updated_at = now()
         WHERE id = NEW.patient_id;
      END IF;
    ELSIF OLD.amount IS DISTINCT FROM NEW.amount AND NEW.patient_id IS NOT NULL THEN
      UPDATE public.patients
         SET paid = GREATEST(0, COALESCE(paid, 0) - COALESCE(OLD.amount, 0) + COALESCE(NEW.amount, 0)),
             updated_at = now()
       WHERE id = NEW.patient_id;
    END IF;
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_dental_jg_payment_balance_delta ON public.payments;
CREATE TRIGGER trg_dental_jg_payment_balance_delta
AFTER INSERT OR UPDATE OF patient_id, amount OR DELETE
ON public.payments
FOR EACH ROW
EXECUTE FUNCTION public.dental_jg_apply_payment_balance_delta();

-- Compatibilidad con APK anteriores que llamaban esta RPC después de sincronizar.
-- El saldo ya lo mantiene el trigger; no se vuelve a sumar ni se fuerza a un máximo.
CREATE OR REPLACE FUNCTION public.sync_patient_paid(p_patient_id uuid, p_new_paid numeric)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = pg_catalog, public
AS $$
DECLARE v_paid numeric(12,2);
BEGIN
  SELECT paid INTO v_paid
  FROM public.patients
  WHERE id = p_patient_id;

  IF v_paid IS NULL THEN
    RAISE EXCEPTION 'Paciente no encontrado o sin permisos.';
  END IF;

  RETURN jsonb_build_object('ok', true, 'paid', v_paid,
    'message', 'El saldo se mantiene mediante los movimientos de payments.');
END;
$$;


-- Verificación de solo lectura:
-- SELECT column_name FROM information_schema.columns
-- WHERE table_schema='public' AND table_name='payments' AND column_name='client_operation_id';
-- SELECT indexname FROM pg_indexes WHERE schemaname='public' AND tablename='payments'
--   AND indexname='payments_client_operation_id_uq';
-- SELECT tgname FROM pg_trigger WHERE tgrelid='public.payments'::regclass AND NOT tgisinternal;


-- DENTAL JG - Fase 7: guardar Tratamiento y Observaciones en sus campos correctos.
-- Migración aditiva: no modifica pacientes existentes, pagos ni saldos.
-- Ejecutar en Supabase después de respaldar y antes de usar la APK/web de Registro corregida.

CREATE SEQUENCE IF NOT EXISTS public.dental_jg_patient_folio_seq;
DO $$
DECLARE v_max bigint; v_last bigint; v_called boolean;
BEGIN
  SELECT max((substring(folio from '[0-9]+$'))::bigint) INTO v_max
  FROM public.patients WHERE folio ~ '[0-9]+$';
  IF coalesce(v_max, 0) > 0 THEN
    SELECT last_value, is_called INTO v_last, v_called FROM public.dental_jg_patient_folio_seq;
    IF NOT v_called OR v_last < v_max THEN PERFORM setval('public.dental_jg_patient_folio_seq', v_max, true); END IF;
  END IF;
END; $$;


CREATE OR REPLACE FUNCTION public.register_dental_jg_patient(
 p_name text, p_phone text, p_treatment text, p_total numeric,
 p_installments integer, p_installment_amount numeric, p_policy_number text, p_clinic text,
 p_first_names text, p_surnames text, p_address text, p_phone2 text, p_observations text,
 p_holder_name text, p_payment_mode text, p_tabulator numeric, p_first_payment_date date,
 p_payment_method text DEFAULT 'efectivo', p_policy_type text DEFAULT NULL,
 p_assigned_manager_id uuid DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  new_id uuid;
  new_folio text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Inicia sesión para registrar clientes.';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.app_user_roles
    WHERE user_id = auth.uid() AND lower(role) = 'registro'
  ) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para registrar clientes.';
  END IF;

  IF length(trim(coalesce(p_holder_name, ''))) = 0
     OR length(trim(coalesce(p_first_names, p_name, ''))) = 0
     OR length(trim(coalesce(p_surnames, ''))) = 0
     OR length(trim(coalesce(p_clinic, ''))) = 0
     OR length(trim(coalesce(p_policy_number, ''))) = 0
     OR length(trim(coalesce(p_address, ''))) = 0
     OR length(trim(coalesce(p_phone, ''))) = 0 THEN
    RAISE EXCEPTION 'Completa todos los campos obligatorios.';
  END IF;

  IF coalesce(p_treatment, '') NOT IN ('Básico', 'Basic', 'Orto', 'VIP', 'Damon') THEN
    RAISE EXCEPTION 'Selecciona un tratamiento válido.';
  END IF;

  IF p_assigned_manager_id IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.collection_managers
    WHERE id = p_assigned_manager_id AND coalesce(active, true)
  ) THEN
    RAISE EXCEPTION 'Selecciona un gestor activo.';
  END IF;

  IF coalesce(p_payment_mode, '') NOT IN ('quincenal', 'mensual') THEN
    RAISE EXCEPTION 'Selecciona periodicidad quincenal o mensual.';
  END IF;
  IF coalesce(p_payment_method, '') NOT IN ('efectivo', 'transferencia') THEN
    RAISE EXCEPTION 'Selecciona forma de pago efectivo o transferencia.';
  END IF;
  IF coalesce(p_total, 0) <= 0 OR coalesce(p_installments, 0) < 1
     OR coalesce(p_installment_amount, 0) <= 0 OR coalesce(p_tabulator, 0) < 0
     OR p_first_payment_date IS NULL THEN
    RAISE EXCEPTION 'Verifica monto total, cantidad por pago, número de pagos, tabulador y fecha del primer pago.';
  END IF;

  new_folio := 'JG-' || lpad(nextval('public.dental_jg_patient_folio_seq')::text, 6, '0');

  INSERT INTO public.patients(
    folio, holder_name, first_names, surnames, address, phone2, observations,
    name, phone, treatment, total, paid, installments, installment_amount,
    policy_number, policy_type, assigned_manager_id, clinic, source_device,
    created_at, updated_at, payment_mode, tabulator, first_payment_date, payment_method
  ) VALUES (
    new_folio, trim(p_holder_name), trim(coalesce(p_first_names, p_name)),
    trim(coalesce(p_surnames, '')), trim(coalesce(p_address, '')),
    trim(coalesce(p_phone2, '')), trim(coalesce(p_observations, '')),
    trim(p_name), trim(p_phone), trim(p_treatment), p_total, 0,
    p_installments, p_installment_amount, trim(p_policy_number),
    nullif(trim(coalesce(p_policy_type, '')), ''), p_assigned_manager_id,
    trim(p_clinic), 'DENTAL JG Registro', now(), now(), p_payment_mode,
    p_tabulator, p_first_payment_date, p_payment_method
  ) RETURNING id INTO new_id;

  RETURN new_id;
END;
$$;

REVOKE ALL ON FUNCTION public.register_dental_jg_patient(
 text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,
 text,text,numeric,date,text,text,uuid
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.register_dental_jg_patient(
 text,text,text,numeric,integer,numeric,text,text,text,text,text,text,text,
 text,text,numeric,date,text,text,uuid
) TO authenticated;



-- DENTAL JG - Fase 8: una cartera por clínica y gestor asignado.
-- No elimina pacientes, pagos, recibos ni reportes históricos.
-- Respaldar Supabase antes de ejecutar.


ALTER TABLE public.collection_portfolios
  ADD COLUMN IF NOT EXISTS manager_id uuid;

-- La clave anterior solo permitía una cartera por clínica y no separaba gestores.
ALTER TABLE public.collection_portfolios
  DROP CONSTRAINT IF EXISTS collection_portfolios_created_by_clinic_name_key;
DROP INDEX IF EXISTS public.collection_portfolios_created_by_clinic_name_key;

CREATE UNIQUE INDEX IF NOT EXISTS collection_portfolios_created_clinic_manager_uq
  ON public.collection_portfolios (created_by, clinic_name, manager_id);
CREATE INDEX IF NOT EXISTS collection_portfolios_manager_idx
  ON public.collection_portfolios (manager_id);

-- Reparte las asignaciones existentes según el gestor realmente guardado en cada paciente.
-- No asigna pacientes sin assigned_manager_id ni sobrescribe un gestor existente.
DO $$
DECLARE
  old_portfolio record;
  grp record;
  new_portfolio_id uuid;
  manager_name text;
BEGIN
  FOR old_portfolio IN
    SELECT p.id, p.created_by, p.clinic_name
    FROM public.collection_portfolios p
    WHERE p.manager_id IS NULL
  LOOP
    FOR grp IN
      SELECT DISTINCT pt.assigned_manager_id AS manager_id
      FROM public.collection_portfolio_patients cpp
      JOIN public.patients pt ON pt.id = cpp.patient_id
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.assigned_manager_id IS NOT NULL
    LOOP
      SELECT cm.full_name INTO manager_name
      FROM public.collection_managers cm
      WHERE cm.id = grp.manager_id AND cm.active IS DISTINCT FROM false;

      IF manager_name IS NULL THEN
        CONTINUE;
      END IF;

      INSERT INTO public.collection_portfolios(created_by, clinic_name, name, manager_id, updated_at)
      VALUES (old_portfolio.created_by, old_portfolio.clinic_name,
              'Cartera - ' || old_portfolio.clinic_name || ' - ' || manager_name,
              grp.manager_id, now())
      ON CONFLICT (created_by, clinic_name, manager_id)
      DO UPDATE SET name = EXCLUDED.name, updated_at = now()
      RETURNING id INTO new_portfolio_id;

      INSERT INTO public.collection_portfolio_patients(created_by, portfolio_id, patient_id)
      SELECT cpp.created_by, new_portfolio_id, cpp.patient_id
      FROM public.collection_portfolio_patients cpp
      JOIN public.patients pt ON pt.id = cpp.patient_id
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.assigned_manager_id = grp.manager_id
      ON CONFLICT (portfolio_id, patient_id) DO NOTHING;

      DELETE FROM public.collection_portfolio_patients cpp
      USING public.patients pt
      WHERE cpp.portfolio_id = old_portfolio.id
        AND pt.id = cpp.patient_id
        AND pt.assigned_manager_id = grp.manager_id;
    END LOOP;
  END LOOP;
END;
$$;


-- Verificación de solo lectura:
-- SELECT clinic_name, manager_id, count(*)
-- FROM public.collection_portfolios GROUP BY clinic_name, manager_id ORDER BY clinic_name;
-- SELECT count(*) AS pacientes_sin_gestor FROM public.patients WHERE assigned_manager_id IS NULL;

-- Fase 9: una sola fila de recibo real por pago, incluso si lo intentan dos cuentas.
-- No elimina recibos. Si ya existen recibos duplicados para un mismo pago, se detiene
-- con un error para que se concilien manualmente en lugar de borrar datos a ciegas.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM public.collection_receipts
    WHERE payment_id IS NOT NULL
    GROUP BY payment_id
    HAVING count(*) > 1
  ) THEN
    RAISE EXCEPTION 'Hay pagos con más de un recibo asociado. No se creó el índice; concilia primero los duplicados sin borrar el historial.';
  END IF;
END;
$$;

CREATE UNIQUE INDEX IF NOT EXISTS collection_receipts_payment_unique
  ON public.collection_receipts (payment_id)
  WHERE payment_id IS NOT NULL;


-- DENTAL JG - Fase 10: acceso por roles y sincronización Gestor por RPC.
-- Elimina políticas permisivas conocidas en pacientes/pagos/clínicas/gestores.
-- Gestor solo puede consultar y registrar movimientos del gestor validado por clave.

CREATE OR REPLACE FUNCTION public.dental_jg_manager_by_key(p_manager_key text)
RETURNS TABLE(id uuid, full_name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para validar al gestor.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  IF length(trim(coalesce(p_manager_key,''))) < 4 THEN RAISE EXCEPTION 'Clave de gestor no válida.'; END IF;
  RETURN QUERY SELECT m.id,m.full_name FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(p_manager_key) LIMIT 1;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_patients(p_manager_key text)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para sincronizar pacientes.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  RETURN QUERY SELECT to_jsonb(p) FROM public.patients p
  WHERE p.assigned_manager_id=v_manager ORDER BY p.created_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_payments(p_manager_key text)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para sincronizar pagos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  RETURN QUERY SELECT to_jsonb(py) FROM public.payments py
  JOIN public.patients pt ON pt.id=py.patient_id
  WHERE pt.assigned_manager_id=v_manager ORDER BY py.paid_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.dental_jg_manager_insert_payment(p_manager_key text,p_payment jsonb)
RETURNS SETOF jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog, public AS $$
DECLARE v_manager uuid; v_patient public.patients; v_payment public.payments; v_operation_id text; v_amount numeric;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para registrar pagos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('gestor','admin')) THEN RAISE EXCEPTION 'Esta cuenta no tiene permiso para usar la sincronización de Gestor.'; END IF;
  SELECT m.id INTO v_manager FROM public.collection_managers m
  WHERE m.active IS DISTINCT FROM false AND m.manager_key=trim(coalesce(p_manager_key,''))
    AND length(trim(coalesce(p_manager_key,''))) >= 4 LIMIT 1;
  IF v_manager IS NULL THEN RAISE EXCEPTION 'Clave de gestor incorrecta o gestor inactivo.'; END IF;
  v_operation_id:=trim(coalesce(p_payment->>'client_operation_id',''));
  IF v_operation_id='' THEN RAISE EXCEPTION 'El pago no incluye identificador único. Actualiza la aplicación Gestor.'; END IF;
  v_amount:=(p_payment->>'amount')::numeric;
  IF v_amount IS NULL OR v_amount<=0 OR v_amount>9999999999.99 THEN RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.'; END IF;
  -- Autoriza al gestor sobre el paciente antes de consultar un identificador existente.
  SELECT p.* INTO v_patient FROM public.patients p
  WHERE p.id=(p_payment->>'patient_id')::uuid AND p.assigned_manager_id=v_manager
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no pertenece a este gestor.'; END IF;

  PERFORM pg_advisory_xact_lock(hashtext('dentaljg-payment-operation:'||v_operation_id));
  SELECT * INTO v_payment FROM public.payments WHERE client_operation_id=v_operation_id LIMIT 1;
  IF FOUND THEN
    IF v_payment.patient_id IS DISTINCT FROM v_patient.id OR round(v_payment.amount,2)<>round(v_amount,2) THEN
      RAISE EXCEPTION 'El identificador de operación ya existe con datos diferentes. No se registró otro pago.';
    END IF;
    RETURN NEXT to_jsonb(v_payment); RETURN;
  END IF;
  IF v_amount > GREATEST(COALESCE(v_patient.total,0)-COALESCE(v_patient.paid,0),0) + 0.009 THEN
    RAISE EXCEPTION 'El pago supera el saldo pendiente actual. Sincroniza el paciente y revisa el historial antes de reintentar.';
  END IF;
  INSERT INTO public.payments(patient_id,patient_name,amount,concept,reference,paid_at,source_device,client_operation_id)
  VALUES(v_patient.id,
    coalesce(nullif(trim(concat_ws(' ',nullif(v_patient.first_names,''),nullif(v_patient.surnames,''))),''),v_patient.name),
    v_amount,coalesce(nullif(trim(p_payment->>'concept'),''),'Abono'),coalesce(p_payment->>'reference',''),
    coalesce(nullif(p_payment->>'paid_at','')::timestamptz,now()),
    coalesce(nullif(p_payment->>'source_device',''),'DENTAL JG APK'),v_operation_id)
  RETURNING * INTO v_payment;
  RETURN NEXT to_jsonb(v_payment);
END; $$;

REVOKE ALL ON FUNCTION public.dental_jg_manager_by_key(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_patients(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_payments(text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.dental_jg_manager_insert_payment(text,jsonb) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_by_key(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_patients(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_payments(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dental_jg_manager_insert_payment(text,jsonb) TO authenticated;

DO $$ DECLARE pol record; BEGIN
  FOR pol IN SELECT tablename,policyname FROM pg_policies WHERE schemaname='public'
    AND tablename IN ('patients','payments','clinics','collection_managers') LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',pol.policyname,pol.tablename);
  END LOOP;
END; $$;

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clinics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collection_managers ENABLE ROW LEVEL SECURITY;

CREATE POLICY dental_jg_staff_read_patients ON public.patients FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
CREATE POLICY dental_jg_staff_update_patients ON public.patients FOR UPDATE TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza'))) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
CREATE POLICY dental_jg_staff_delete_patients ON public.patients FOR DELETE TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
REVOKE ALL ON public.patients FROM PUBLIC,anon,authenticated;
GRANT SELECT,UPDATE,DELETE ON public.patients TO authenticated;

CREATE POLICY dental_jg_staff_read_payments ON public.payments FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','cobranza')));
REVOKE ALL ON public.payments FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.payments TO authenticated;

CREATE POLICY dental_jg_authenticated_read_clinics ON public.clinics FOR SELECT TO authenticated USING (true);
CREATE POLICY dental_jg_admin_manage_clinics ON public.clinics FOR ALL TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin')) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));
REVOKE ALL ON public.clinics FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.clinics TO authenticated;

REVOKE ALL ON public.collection_managers FROM PUBLIC,anon,authenticated;
REVOKE SELECT(manager_key) ON public.collection_managers FROM PUBLIC,anon,authenticated;
GRANT SELECT(id,created_by,full_name,phone,active,created_at,updated_at) ON public.collection_managers TO authenticated;
GRANT INSERT(created_by,full_name,phone,manager_key) ON public.collection_managers TO authenticated;
GRANT UPDATE(full_name,phone,manager_key,active,updated_at) ON public.collection_managers TO authenticated;
GRANT DELETE ON public.collection_managers TO authenticated;
CREATE POLICY dental_jg_staff_read_managers ON public.collection_managers FOR SELECT TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role) IN ('admin','registro','cobranza')));
CREATE POLICY dental_jg_admin_manage_managers ON public.collection_managers FOR ALL TO authenticated USING (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin')) WITH CHECK (EXISTS(
 SELECT 1 FROM public.app_user_roles r WHERE r.user_id=auth.uid() AND lower(r.role)='admin'));


-- Fase 11: validar recibos contra el paciente/pago real y aceptar gestores compartidos.
-- Corrige el rechazo de gestores creados por Administración pero seleccionados en Cobranza.
CREATE OR REPLACE FUNCTION public.create_collection_receipt(
  p_payment_id uuid,
  p_patient_id uuid,
  p_patient_name text,
  p_clinic text,
  p_payment_amount numeric,
  p_previous_balance numeric,
  p_tabulator numeric,
  p_new_balance numeric,
  p_concept text,
  p_notes text,
  p_snapshot jsonb,
  p_manager_id uuid DEFAULT NULL::uuid
) RETURNS public.collection_receipts
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_temp
AS $$
DECLARE
  s public.collection_receipt_settings;
  r public.collection_receipts;
  v_folio text;
  v_payment_patient uuid;
  v_payment_amount numeric;
  v_canonical_patient_name text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para generar recibos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles ar WHERE ar.user_id=auth.uid() AND lower(ar.role) IN ('admin','cobranza')) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para generar recibos.';
  END IF;
  IF p_payment_amount IS NULL OR p_payment_amount <= 0 OR p_payment_amount > 9999999999.99 THEN
    RAISE EXCEPTION 'El importe debe ser mayor que cero y estar dentro del límite permitido.';
  END IF;
  IF COALESCE(p_previous_balance,0) < 0 OR COALESCE(p_tabulator,0) < 0 OR COALESCE(p_new_balance,0) < 0 THEN
    RAISE EXCEPTION 'Los importes no pueden ser negativos.';
  END IF;
  IF COALESCE(p_tabulator,0) > p_payment_amount THEN RAISE EXCEPTION 'El tabulador/descuento no puede superar el importe del recibo.'; END IF;
  IF length(COALESCE(p_patient_name,'')) > 200 OR length(COALESCE(p_clinic,'')) > 200 OR length(COALESCE(p_concept,'')) > 200 OR length(COALESCE(p_notes,'')) > 2000 THEN
    RAISE EXCEPTION 'Uno de los campos de texto supera el límite permitido.';
  END IF;
  IF p_snapshot IS NOT NULL AND jsonb_typeof(p_snapshot) <> 'object' THEN RAISE EXCEPTION 'Los datos de impresión no tienen un formato válido.'; END IF;

  IF p_patient_id IS NOT NULL THEN
    SELECT COALESCE(NULLIF(trim(concat_ws(' ',NULLIF(trim(pt.first_names),''),NULLIF(trim(pt.surnames),''))),''),NULLIF(trim(pt.name),''))
      INTO v_canonical_patient_name
      FROM public.patients pt WHERE pt.id=p_patient_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no existe o no tienes permiso para consultarlo.'; END IF;
    IF COALESCE(v_canonical_patient_name,'') <> '' THEN p_patient_name := v_canonical_patient_name; END IF;
  END IF;

  IF p_manager_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.collection_managers m WHERE m.id=p_manager_id AND m.active IS DISTINCT FROM false
  ) THEN RAISE EXCEPTION 'El gestor seleccionado no existe o está inactivo.'; END IF;

  IF p_payment_id IS NOT NULL THEN
    SELECT py.patient_id,py.amount INTO v_payment_patient,v_payment_amount
      FROM public.payments py WHERE py.id=p_payment_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'El pago no existe o no tienes permiso para consultarlo.'; END IF;
    IF p_patient_id IS NULL OR v_payment_patient IS DISTINCT FROM p_patient_id THEN RAISE EXCEPTION 'El pago no corresponde al paciente seleccionado.'; END IF;
    IF round(v_payment_amount::numeric,2) <> round(p_payment_amount::numeric,2) THEN RAISE EXCEPTION 'El importe del recibo debe coincidir con el pago registrado.'; END IF;
    PERFORM pg_advisory_xact_lock(hashtext('dentaljg-payment:' || p_payment_id::text));
    SELECT * INTO r FROM public.collection_receipts WHERE payment_id=p_payment_id LIMIT 1;
    IF FOUND THEN
      IF r.created_by <> auth.uid() THEN RAISE EXCEPTION 'Este pago ya tiene un recibo asociado. Solicita acceso a la cuenta que lo generó.'; END IF;
      RETURN r;
    END IF;
  END IF;

  INSERT INTO public.collection_receipt_settings(user_id) VALUES(auth.uid()) ON CONFLICT(user_id) DO NOTHING;
  SELECT * INTO s FROM public.collection_receipt_settings WHERE user_id=auth.uid() FOR UPDATE;
  v_folio := COALESCE(s.folio_prefix,'JG-') || lpad(s.next_folio::text,greatest(s.folio_digits,length(s.next_folio::text)),'0');
  UPDATE public.collection_receipt_settings SET next_folio=next_folio+1,updated_at=now() WHERE user_id=auth.uid();
  INSERT INTO public.collection_receipts(created_by,folio,payment_id,patient_id,manager_id,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  VALUES(auth.uid(),v_folio,p_payment_id,p_patient_id,p_manager_id,COALESCE(p_patient_name,''),COALESCE(p_clinic,''),p_payment_amount,COALESCE(p_previous_balance,0),COALESCE(p_tabulator,0),p_payment_amount-COALESCE(p_tabulator,0),COALESCE(p_new_balance,0),COALESCE(p_concept,'Abono'),COALESCE(p_notes,''),COALESCE(p_snapshot,'{}'::jsonb))
  RETURNING * INTO r;
  RETURN r;
END;
$$;

REVOKE ALL ON FUNCTION public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) TO authenticated;

-- Fase 12: proteger recibos programados y evitar nombres/gestores inconsistentes.
CREATE OR REPLACE FUNCTION public.create_scheduled_collection_receipt(
  p_patient_id uuid,
  p_patient_name text,
  p_clinic text,
  p_payment_amount numeric,
  p_previous_balance numeric,
  p_tabulator numeric,
  p_new_balance numeric,
  p_concept text,
  p_notes text,
  p_snapshot jsonb,
  p_manager_id uuid,
  p_scheduled_for date
) RETURNS public.collection_receipts
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_temp
AS $$
DECLARE
  r public.collection_receipts;
  s public.collection_receipt_settings;
  v_folio text;
  v_canonical_patient_name text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Inicia sesión para generar recibos.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_user_roles ar WHERE ar.user_id=auth.uid() AND lower(ar.role) IN ('admin','cobranza')) THEN
    RAISE EXCEPTION 'Esta cuenta no tiene permiso para generar recibos.';
  END IF;
  IF p_patient_id IS NULL OR p_scheduled_for IS NULL THEN RAISE EXCEPTION 'Falta el cliente o la fecha programada.'; END IF;
  IF COALESCE(p_payment_amount,0) <= 0 OR COALESCE(p_previous_balance,0) < 0 OR COALESCE(p_tabulator,0) < 0 OR COALESCE(p_new_balance,0) < 0 THEN
    RAISE EXCEPTION 'Verifica el importe, saldo y tabulador.';
  END IF;
  IF COALESCE(p_tabulator,0) > p_payment_amount THEN RAISE EXCEPTION 'El tabulador/descuento no puede superar el importe del recibo.'; END IF;
  IF p_payment_amount > COALESCE(p_previous_balance,0) + 0.009 THEN RAISE EXCEPTION 'El recibo programado no puede superar el saldo pendiente.'; END IF;
  SELECT COALESCE(NULLIF(trim(concat_ws(' ',NULLIF(trim(pt.first_names),''),NULLIF(trim(pt.surnames),''))),''),NULLIF(trim(pt.name),''))
    INTO v_canonical_patient_name FROM public.patients pt WHERE pt.id=p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'El paciente no existe o no tienes permiso para consultarlo.'; END IF;
  IF COALESCE(v_canonical_patient_name,'') <> '' THEN p_patient_name := v_canonical_patient_name; END IF;
  IF p_manager_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.collection_managers m WHERE m.id=p_manager_id AND m.active IS DISTINCT FROM false) THEN
    RAISE EXCEPTION 'El gestor seleccionado no existe o está inactivo.';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('dentaljg-scheduled-receipt:'||auth.uid()::text||':'||p_patient_id::text||':'||p_scheduled_for::text));
  SELECT * INTO r FROM public.collection_receipts
   WHERE created_by=auth.uid() AND patient_id=p_patient_id AND scheduled_for=p_scheduled_for AND payment_id IS NULL LIMIT 1;
  IF FOUND THEN RETURN r; END IF;

  INSERT INTO public.collection_receipt_settings(user_id) VALUES(auth.uid()) ON CONFLICT(user_id) DO NOTHING;
  SELECT * INTO s FROM public.collection_receipt_settings WHERE user_id=auth.uid() FOR UPDATE;
  v_folio := COALESCE(s.folio_prefix,'JG-') || lpad(s.next_folio::text,greatest(s.folio_digits,length(s.next_folio::text)),'0');
  UPDATE public.collection_receipt_settings SET next_folio=next_folio+1,updated_at=now() WHERE user_id=auth.uid();
  INSERT INTO public.collection_receipts(created_by,folio,payment_id,patient_id,manager_id,scheduled_for,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  VALUES(auth.uid(),v_folio,NULL,p_patient_id,p_manager_id,p_scheduled_for,COALESCE(p_patient_name,''),COALESCE(p_clinic,''),p_payment_amount,COALESCE(p_previous_balance,0),COALESCE(p_tabulator,0),GREATEST(0,p_payment_amount-COALESCE(p_tabulator,0)),COALESCE(p_new_balance,0),COALESCE(p_concept,'Pago programado'),COALESCE(p_notes,''),COALESCE(p_snapshot,'{}'::jsonb))
  RETURNING * INTO r;
  RETURN r;
EXCEPTION WHEN unique_violation THEN
  SELECT * INTO r FROM public.collection_receipts WHERE created_by=auth.uid() AND patient_id=p_patient_id AND scheduled_for=p_scheduled_for AND payment_id IS NULL LIMIT 1;
  IF FOUND THEN RETURN r; END IF;
  RAISE;
END;
$$;

REVOKE ALL ON FUNCTION public.create_scheduled_collection_receipt(uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid,date) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.create_scheduled_collection_receipt(uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid,date) TO authenticated;

COMMIT;
