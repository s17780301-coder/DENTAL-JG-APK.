-- DENTAL JG 10.8.9 — gestores compartidos, importes por gestor y archivo de reportes quincenales.
-- Ejecutar UNA vez en Supabase SQL Editor del proyecto conectado a todas las apps.
-- No elimina pacientes, pagos ni recibos existentes.
begin;

-- Vincular cada recibo a su gestor para que Administración pueda sumar importes por gestor.
alter table public.collection_receipts add column if not exists manager_id uuid references public.collection_managers(id) on delete set null;

-- Un reporte conserva la fotografía del listado impreso de una quincena y gestor.
create table if not exists public.collection_quincena_reports (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade default auth.uid(),
  quincena_date date not null,
  manager_id uuid not null references public.collection_managers(id) on delete restrict,
  manager_name text not null default '',
  report_rows jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(created_by, quincena_date, manager_id)
);
alter table public.collection_quincena_reports enable row level security;
grant select, insert, update, delete on public.collection_quincena_reports to authenticated;
drop policy if exists "quincena reports app access" on public.collection_quincena_reports;
create policy "quincena reports app access" on public.collection_quincena_reports for all to authenticated
using (
  created_by = auth.uid()
  or exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin')
)
with check (
  (created_by = auth.uid() and exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('admin','cobranza','gestor')))
  or exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin')
);

-- Administración puede consultar el catálogo compartido de gestores y sus carteras.
grant select, insert, update, delete on public.collection_managers to authenticated;
drop policy if exists "admin manages shared collection managers" on public.collection_managers;
create policy "admin manages shared collection managers" on public.collection_managers for all to authenticated
using (exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'))
with check (exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'));
drop policy if exists "authorized apps view shared collection managers" on public.collection_managers;
create policy "authorized apps view shared collection managers" on public.collection_managers for select to authenticated
using (exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role in ('admin','cobranza','registro','gestor')));

-- El rol administrador puede consultar los recibos para mostrar los totales por gestor.
drop policy if exists "admin views all collection receipts for manager totals" on public.collection_receipts;
create policy "admin views all collection receipts for manager totals" on public.collection_receipts for select to authenticated
using (exists(select 1 from public.app_user_roles r where r.user_id=auth.uid() and r.role='admin'));

create index if not exists collection_quincena_reports_date_idx on public.collection_quincena_reports(quincena_date desc);
create index if not exists collection_quincena_reports_manager_idx on public.collection_quincena_reports(manager_id, quincena_date desc);
create index if not exists collection_receipts_manager_idx on public.collection_receipts(manager_id, created_at desc);
commit;

-- Verificación: debe devolver las columnas manager_id y la tabla de reportes.
select table_name, column_name from information_schema.columns
where table_schema='public' and ((table_name='collection_receipts' and column_name='manager_id') or table_name='collection_quincena_reports')
order by table_name, ordinal_position;

-- Versión de la función de recibos que conserva el gestor elegido en el formulario.
create or replace function public.create_collection_receipt(
  p_payment_id uuid, p_patient_id uuid, p_patient_name text, p_clinic text,
  p_payment_amount numeric, p_previous_balance numeric, p_tabulator numeric,
  p_new_balance numeric, p_concept text, p_notes text, p_snapshot jsonb,
  p_manager_id uuid default null
) returns public.collection_receipts
language plpgsql security invoker set search_path=public as $$
declare s public.collection_receipt_settings; r public.collection_receipts; v_folio text;
begin
  if auth.uid() is null then raise exception 'Inicia sesión para generar recibos.'; end if;
  if coalesce(p_payment_amount,0) < 0 or coalesce(p_previous_balance,0) < 0 or coalesce(p_tabulator,0) < 0 then raise exception 'Los importes no pueden ser negativos.'; end if;
  if p_payment_id is not null then
    select * into r from public.collection_receipts where created_by=auth.uid() and payment_id=p_payment_id limit 1;
    if found then return r; end if;
  end if;
  insert into public.collection_receipt_settings(user_id) values(auth.uid()) on conflict(user_id) do nothing;
  select * into s from public.collection_receipt_settings where user_id=auth.uid() for update;
  v_folio := coalesce(s.folio_prefix,'JG-') || lpad(s.next_folio::text, greatest(s.folio_digits, length(s.next_folio::text)), '0');
  update public.collection_receipt_settings set next_folio=next_folio+1, updated_at=now() where user_id=auth.uid();
  insert into public.collection_receipts(created_by,folio,payment_id,patient_id,manager_id,patient_name,clinic,payment_amount,previous_balance,tabulator,net_amount,new_balance,concept,notes,receipt_snapshot)
  values(auth.uid(),v_folio,p_payment_id,p_patient_id,p_manager_id,coalesce(p_patient_name,''),coalesce(p_clinic,''),coalesce(p_payment_amount,0),coalesce(p_previous_balance,0),coalesce(p_tabulator,0),greatest(0,coalesce(p_payment_amount,0)-coalesce(p_tabulator,0)),coalesce(p_new_balance,0),coalesce(p_concept,'Abono'),coalesce(p_notes,''),coalesce(p_snapshot,'{}'::jsonb)) returning * into r;
  return r;
end; $$;
grant execute on function public.create_collection_receipt(uuid,uuid,text,text,numeric,numeric,numeric,numeric,text,text,jsonb,uuid) to authenticated;
