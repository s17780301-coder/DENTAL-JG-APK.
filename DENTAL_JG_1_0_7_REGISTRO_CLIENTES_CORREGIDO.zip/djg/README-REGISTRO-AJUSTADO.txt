DENTAL JG 10.8 — AJUSTE DEL MÓDULO REGISTRO

CAMBIOS INCLUIDOS
- Se sincronizó el código JavaScript de Registro web y Android.
- El control de acceso admite los roles registro y admin, en consonancia con la función de Supabase.
- Se evitaron comprobaciones duplicadas de sesión/rol durante el inicio de sesión.
- Se mejoraron mensajes de error, validación de pagos y manejo de errores de conexión.
- Se agregó SUPABASE_REGISTRO_MINIMO_Y_ASIGNAR_ROL.sql como referencia de SQL acotado a Registro.

IMPORTANTE
La cuenta clinicadentaljgadmon@outlook.com ya fue asignada al rol registro y el SQL mínimo ya se ejecutó con éxito. No vuelvas a ejecutar SQL por rutina.
No ejecutes la migración amplia DENTAL_JG_10_8_ARQUITECTURA_REGISTRO_COBRANZA.sql solo para habilitar Registro: incluye cambios de políticas de patients y objetos de cartera de Cobranza.

PRUEBA RECOMENDADA
1. Publica/sube el contenido actualizado del proyecto a GitHub.
2. Ejecuta Actions y comprueba que termine la compilación de las cuatro APK.
3. Instala la APK DENTAL-JG-Registro-de-Clientes.apk.
4. Inicia sesión con clinicadentaljgadmon@outlook.com y registra un cliente de prueba claramente identificado.
5. Comprueba que el cliente aparece en Cobranza antes de registrar pacientes reales.

La compilación y la prueba real contra el proyecto Supabase no se pueden declarar aprobadas hasta ejecutar el workflow y probar la app instalada.
